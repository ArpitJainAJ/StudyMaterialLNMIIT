The file named 'Assignment 3.sql' contains the solution of the assignment.
The file named 'Assignment 3 - result.txt' contains the result obtained in terminal after executnig queries in 'Assignment 2.sql' exactly in order as copied.
----------------------------------------------------------------------------
How of execute?

Method 1:
Open the 'Assignment 3.sql' as a text file and copy all contents using Ctrl+A followed by Ctrl+C (to make sure you also copy and linebreaks). Open terminal as sudo or any appropriate user, run mysql and paste these quesries using Ctrl+Shift+V. One by one all queries will execute.

Method 2:
Import the SQL file after running mysql with appropriate user permission and observe and match the output in terminal with the file 'Assignment 3 - result.txt'
----------------------------------------------------------------------------
