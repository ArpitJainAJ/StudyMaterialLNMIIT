The file named 'Assignment 4.sql' contains the solution of the assignment.
The file named 'Assignment 4 - result.txt' contains the result obtained in terminal after executnig queries in 'Assignment 2.sql' exactly in order as copied.
----------------------------------------------------------------------------
How of execute?

Method 1:
Open the 'Assignment 4.sql' as a text file and copy all contents using Ctrl+A followed by Ctrl+C (to make sure you also copy and linebreaks). Open terminal as sudo or any appropriate user, run mysql and paste these quesries using Ctrl+Shift+V. One by one all queries will execute. Observe and match the output in terminal with the file 'Assignment 3 - result.txt'

Method 2:
Import the SQL file using 'source Assignment 4.sql' after running mysql with appropriate user permission and observe and similarize the output in terminal with the file 'Assignment 3 - result.txt'
----------------------------------------------------------------------------
