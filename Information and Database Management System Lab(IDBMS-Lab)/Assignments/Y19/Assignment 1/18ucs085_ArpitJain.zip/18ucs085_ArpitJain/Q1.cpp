/*
Q1. Requirements: This assignment requires the knowledge of File I/O and Structure concepts of C
programming.
The assignment should be implemented using C/C++ language. The details of the assignment are
as follows:
1. Create a file students (.txt or .dat) to store information of students of a university. The file
should store student ID, NAME, and BRANCH. The following constraints should be
satisfied to store the information in student table
- Each student should have a unique student ID. - Insertion of a student with existing student ID should not be allowed.
Perform the following operation on the created student records. (NOTE: Create a
menu driven program for better understanding)
i. Insert 10 students in the student database.
ii. Modify the NAME or BRANCH (CSE, EE, and ECE) of the student. Note that
the modification of Student ID should not be allowed.
iii. Delete the student using the Student ID.
iv. Search the list of students using BRANCH.
v. Search the student by their NAME.
*/

#include<bits/stdc++.h>
#include<iostream>

using namespace std;

#define IDlength 16
#define Nlength 64
#define Blength 8
#define mainstudentfile "students.txt"
#define tempstudentfile "temp-students.txt"

bool compare ( char a[], char b[])
{
	for(int i=0;;++i)
	{
		if(a[i]!=b[i])
			return false;
		else if(a[i]=='\0')
			return true;
	}
	return true;
}

void copy(char a[], char b[])
{
	int i;
	for(i=0;;++i)
	{
		if(a[i]=='\0')
			break;
		else
			b[i]=a[i];
	}
	b[i]='\0';
}

class Student
{
	char id[IDlength];
	char name[Nlength];
	char branch[Blength];
public:

	void getData()
	{
		cout<<"Enter Student's ID(max length 15): ";
		cin>>id;
		cout<<"Enter Student's Name(max length 63): ";
		cin>>name;
		cout<<"Enter Student's Branch(max length 7): ";
		cin>>branch;
	}

	void showData()
	{
		cout<<"Studdent's ID: "<<id<<", Name: "<<name<<", Branch: "<<branch<<endl;
	}
	void setData(Student& a)
	{
		copy(a.getid(),id);
		copy(a.getname(), name);
		copy(a.getbranch(),branch);
	}
	void setid(char a[])
	{
		copy(a, id);
	}
	char* getid()
	{
		return id;
	}
	void setname(char a[])
	{
		copy(a, name);
	}
	char* getname()
	{
		return name;
	}
	void setbranch(char a[])
	{
		copy(a, branch);
	}
	char* getbranch()
	{
		return branch;
	}
};

class AdminStudent
{	
public:
	bool SearchID(char temp[])
	{
		fstream f;
		Student search;
		f.open(mainstudentfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getid(), temp)==true)
			{
				f.close();
				return true;
			}
		}
		f.close();
		return false;
	}

	void SearchName()
	{
		char temp[Nlength];
		cout<<"Enter name of student to be searched: ";
		cin>>temp;
		fstream f;
		Student search, newrecord;
		newrecord.setname(temp);
		f.open(mainstudentfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getname(), newrecord.getname())==true)
			{
				cout<<endl<<"Student's ID: "<<search.getid()<<", Branch: "<<search.getbranch()<<endl;
			}
		}
		f.close();
	}

	void SearchBranch()
	{
		char temp[Blength];
		cout<<"Enter the branch of student to be searched: ";
		cin>>temp;
		fstream f;
		Student search, newrecord;
		newrecord.setbranch(temp);
		f.open(mainstudentfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getbranch(), newrecord.getbranch())==true)
			{
				cout<<endl<<"Student's ID: "<<search.getid()<<", Name: "<<search.getname()<<endl;
			}
		}
		f.close();
	}
	
	void AddRecord()
	{
		fstream f;
		Student newrecord;
		newrecord.getData();
		if(SearchID(newrecord.getid())==false)
		{
			f.open(mainstudentfile, ios::app|ios::binary);
			f.write((char*) &newrecord, sizeof(newrecord));
			f.close();
			cout<<"Record added successfully"<<endl;
		}
		else
			cout<<"Record with same Student ID exists"<<endl;
	}

	void Delete()
	{
		char temp[IDlength];
		Student deleterecord, newrecord;
		cout<<"Enter Student's ID for deletion: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchID(newrecord.getid())==true)
		{
			fstream f1,f2;
			f1.open(mainstudentfile, ios::in|ios::binary);
			f2.open(tempstudentfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), newrecord.getid())==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
			}
			f1.close();
			f2.close();
			remove(mainstudentfile);
			rename(tempstudentfile,mainstudentfile);
			cout<<endl<<"Deletion of record is successful"<<endl;
		}
		else
			cout<<endl<<"Student's ID not found";

	}
	void ModifyName()
	{
		char temp[IDlength];
		Student deleterecord, newrecord;
		cout<<"Enter Student's ID for Name modification: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchID(newrecord.getid())==true)
		{
			char temp[Nlength];
			cout<<endl<<"Enter Student's New Name: ";
			cin>>temp;
			newrecord.setname(temp);
			fstream f1,f2;
			f1.open(mainstudentfile, ios::in|ios::binary);
			f2.open(tempstudentfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), newrecord.getid())==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
				else
				{
					newrecord.setbranch(deleterecord.getbranch());
					f2.write((char*)&newrecord, sizeof(newrecord));
					cout<<"New Data-> ";
					newrecord.showData();
					break;
				}
			}
			f1.close();
			f2.close();
			remove(mainstudentfile);
			rename(tempstudentfile,mainstudentfile);
			cout<<endl<<"Modification of record is successful"<<endl;
		}
		else
			cout<<endl<<"Student's ID not found";
	}
	void ModifyBranch()
	{
		char temp[IDlength];
		Student deleterecord,newrecord;
		cout<<"Enter Student's ID for Branch modification: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchID(newrecord.getid())==true)
		{
			char temp[Nlength];
			cout<<endl<<"Enter Student's New Branch: ";
			cin>>temp;
			newrecord.setbranch(temp);
			fstream f1,f2;
			f1.open(mainstudentfile, ios::in|ios::binary);
			f2.open(tempstudentfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), newrecord.getid())==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
				else
				{
					newrecord.setname(deleterecord.getname());
					f2.write((char*)&newrecord, sizeof(newrecord));
					cout<<"New Data-> ";
					newrecord.showData();
				}
			}
			f1.close();
			f2.close();
			if((remove(mainstudentfile))==0)
			{
				rename(tempstudentfile,mainstudentfile);
				cout<<endl<<"Modification of record is successful"<<endl;
			}
			else
			{
				cout<<"Error in modification of record"<<endl;
			}
		}
		else
			cout<<endl<<"Student's ID not found";
	}
};

int main()
{
	AdminStudent arpit;
	bool flag=true;
		cout<<"1: To add a student in database."<<endl;
		cout<<"2. To modify the name of a student."<<endl;
		cout<<"3. To modify the branch of a student."<<endl;
		cout<<"4. To delete the student's data from database"<<endl;
		cout<<"5. Search the student using BRANCH."<<endl;
		cout<<"6. Search the student using NAME."<<endl;
		cout<<"0. To exit this Program"<<endl;
	while(flag)
	{
		cout<<endl	<<"Enter value:";
		int in;
		cin>>in;
		switch(in)
		{
			case 1:
				arpit.AddRecord();
				break;

			case 2:
				arpit.ModifyName();
				break;

			case 3:
				arpit.ModifyBranch();
				break;

			case 4:
				arpit.Delete();
				break;

			case 5:
				arpit.SearchBranch();
				break;

			case 6:
				arpit.SearchName();
				break;

			case 0:
			flag=false;
		}
	}
	return 0;
}