/*
Q1. Requirements: This assignment requires the knowledge of File I/O and Structure concepts of C
programming.
The assignment should be implemented using C/C++ language. The details of the assignment are
as follows:
1. Create a file students (.txt or .dat) to store information of students of a university. The file
should store student ID, NAME, and BRANCH. The following constraints should be
satisfied to store the information in student table
- Each student should have a unique student ID. - Insertion of a student with existing student ID should not be allowed.
Perform the following operation on the created student records. (NOTE: Create a
menu driven program for better understanding)
i. Insert 10 students in the student database.
ii. Modify the NAME or BRANCH (CSE, EE, and ECE) of the student. Note that
the modification of Student ID should not be allowed.
iii. Delete the student using the Student ID.
iv. Search the list of students using BRANCH.
v. Search the student by their NAME.

Q2. 2. Create a file marks (.txt or .dat) to store marks (assuming same subjects for all branch
students) of registered students of a university. The file should store student ID, marks of
DBMS, DS, C, TOTAL, and PERCENTAGE The following constraints should be
satisfied to store the information in student table
- Marks of only the registered students are allowed to store in the table. - The maximum marks of each subject cannot exceed 100.

Perform the following query operation using the student and marks information.
(NOTE: Create a menu driven program for better understanding)
i. Insert marks of all the registered students.
ii. Updating marks of one subject should also update TOTAL and
PERCENTAGE marks.
iii. Deletion of a student record from the student file should also delete his marks
records from the marks file as the student is no longer a registered student.
iv. Show the marks list (Marks of all subjects, TOTAL, and PERCENTAGE) of a
student using his student ID.
v. Search the students with PERCENTAGE above a threshold.
vi. Search the students of a particular BRANCH with PERCENTAGE above a
threshold.
*/

#include<bits/stdc++.h>
#include<iostream>

using namespace std;

#define IDlength 16
#define Nlength 64
#define Blength 8
#define mainstudentfile "students.txt"
#define tempstudentfile "temp-students.txt"
#define mainmarksfile "marks.txt"
#define	tempmarksfile "temp-marks.txt"

bool compare ( char a[], char b[])
{
	for(int i=0;;++i)
	{
		if(a[i]!=b[i])
			return false;
		else if(a[i]=='\0')
			return true;
	}
	return true;
}

void copy(char a[], char b[])
{
	int i;
	for(i=0;;++i)
	{
		if(a[i]=='\0')
			break;
		else
			b[i]=a[i];
	}
	b[i]='\0';
}

class Student
{
	char id[IDlength];
	char name[Nlength];
	char branch[Blength];
public:

	void getData()
	{
		cout<<"Enter Student's ID(max length 15): ";
		cin>>id;
		cout<<"Enter Student's Name(max length 63): ";
		cin>>name;
		cout<<"Enter Student's Branch(max length 7): ";
		cin>>branch;
	}

	void showData()
	{
		cout<<"Studdent's ID: "<<id<<", Name: "<<name<<", Branch: "<<branch<<endl;
	}
	void setData(Student& a)
	{
		copy(a.getid(),id);
		copy(a.getname(), name);
		copy(a.getbranch(),branch);
	}
	void setid(char a[])
	{
		copy(a, id);
	}
	char* getid()
	{
		return id;
	}
	void setname(char a[])
	{
		copy(a, name);
	}
	char* getname()
	{
		return name;
	}
	void setbranch(char a[])
	{
		copy(a, branch);
	}
	char* getbranch()
	{
		return branch;
	}
};

class Marks
{
	char id[IDlength];
	int mdbms;
	int mds;
	int mc;
	int total;
	double percentage;

public:
	void getData()
	{
		cout<<"Enter Student's ID(max length 15): ";
		cin>>id;
		do{
			cout<<"Enter marks in DBMS(maximum marks are 100): ";
			cin>>mdbms;
		}while(mdbms>100);
		do{
			cout<<"Enter marks in DS(maximum marks are 100): ";
			cin>>mds;
		}while(mds>100);
		do{
			cout<<"Enter marks in C(maximum marks are 100): ";
			cin>>mc;
		}while(mc>100);
		calculatetotal();
		calculatepercentage();
	}
	void calculatetotal()
	{
		total=mdbms+mds+mc;
	}
	void calculatepercentage()
	{
		calculatetotal();
		percentage=((double)total)/3;
	}

	void showData()
	{
		cout<<"Student's ID: "<<id<<", Marks(DBMS): "<<mdbms<<", Marks(DS): "<<mds<<", Marks(C): "<<mc<<", Total: "<<total<<", Percentage: "<<percentage<<"%."<<endl;
	}

	void setData(Marks & a)
	{
		copy(a.getid(), id);
		mdbms=a.getmdbms();
		mds=a.getmds();
		mc=a.getmc();
		calculatetotal();
		total=a.gettotal();
		calculatepercentage();
		percentage=a.getpercentage();
	}
	void setid(char a[])
	{
		copy(a, id);
	}
	char* getid()
	{
		return id;
	}
	void setmdbms(int a)
	{
		mdbms=a;
	}
	int getmdbms()
	{
		return mdbms;
	}
	void setmds(int a)
	{
		mds=a;
	}
	int getmds()
	{
		return mds;
	}
	void setmc(int a)
	{
		mc=a;
	}
	int getmc()
	{
		return mc;
	}
	int gettotal()
	{
		return total;
	}
	double getpercentage()
	{
		return percentage;
	}
};

class AdminStudent
{	
public:
	bool SearchIDStudents(char temp[])
	{
		fstream f;
		Student search;
		f.open(mainstudentfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getid(), temp)==true)
			{
				f.close();
				return true;
			}
		}
		f.close();
		return false;
	}

	void SearchName()
	{
		char temp[Nlength];
		cout<<"Enter name of student to be searched: ";
		cin>>temp;
		fstream f;
		Student search, newrecord;
		newrecord.setname(temp);
		f.open(mainstudentfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getname(), newrecord.getname())==true)
			{
				cout<<endl<<"Student's ID: "<<search.getid()<<", Branch: "<<search.getbranch()<<endl;
			}
		}
		f.close();
	}

	void SearchBranch()
	{
		char temp[Blength];
		cout<<"Enter the branch of student to be searched: ";
		cin>>temp;
		fstream f;
		Student search, newrecord;
		newrecord.setbranch(temp);
		f.open(mainstudentfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getbranch(), newrecord.getbranch())==true)
			{
				cout<<endl<<"Student's ID: "<<search.getid()<<", Name: "<<search.getname()<<endl;
			}
		}
		f.close();
	}
	
	void AddRecord()
	{
		fstream f;
		Student newrecord;
		newrecord.getData();
		if(SearchIDStudents(newrecord.getid())==false)
		{
			f.open(mainstudentfile, ios::app|ios::binary);
			f.write((char*) &newrecord, sizeof(newrecord));
			f.close();
			cout<<"Record added successfully"<<endl;
		}
		else
			cout<<"Record with same Student ID exists"<<endl;
	}

	void Delete()
	{
		char temp[IDlength];
		Student deleterecord, newrecord;
		cout<<"Enter Student's ID for deletion: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchIDStudents(newrecord.getid())==true)
		{
			fstream f1,f2;
			f1.open(mainstudentfile, ios::in|ios::binary);
			f2.open(tempstudentfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), newrecord.getid())==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
				else
				{
					Marks deletemarks;
					deletemarks.setid(deleterecord.getid());
					DeleteMarks(deletemarks);
				}
			}
			f1.close();
			f2.close();
			remove(mainstudentfile);
			rename(tempstudentfile,mainstudentfile);
			cout<<endl<<"Deletion of record is successful"<<endl;
		}
		else
			cout<<endl<<"Student's ID not found";

	}
	void ModifyName()
	{
		char temp[IDlength];
		Student deleterecord, newrecord;
		cout<<"Enter Student's ID for Name modification: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchIDStudents(newrecord.getid())==true)
		{
			char temp[Nlength];
			cout<<endl<<"Enter Student's New Name: ";
			cin>>temp;
			newrecord.setname(temp);
			fstream f1,f2;
			f1.open(mainstudentfile, ios::in|ios::binary);
			f2.open(tempstudentfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), newrecord.getid())==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
				else
				{
					newrecord.setbranch(deleterecord.getbranch());
					f2.write((char*)&newrecord, sizeof(newrecord));
					cout<<"New Data-> ";
					newrecord.showData();
					break;
				}
			}
			f1.close();
			f2.close();
			remove(mainstudentfile);
			rename(tempstudentfile,mainstudentfile);
			cout<<endl<<"Modification of record is successful"<<endl;
		}
		else
			cout<<endl<<"Student's ID not found";
	}
	void ModifyBranch()
	{
		char temp[IDlength];
		Student deleterecord,newrecord;
		cout<<"Enter Student's ID for Branch modification: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchIDStudents(newrecord.getid())==true)
		{
			char temp[Nlength];
			cout<<endl<<"Enter Student's New Branch: ";
			cin>>temp;
			newrecord.setbranch(temp);
			fstream f1,f2;
			f1.open(mainstudentfile, ios::in|ios::binary);
			f2.open(tempstudentfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), newrecord.getid())==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
				else
				{
					newrecord.setname(deleterecord.getname());
					f2.write((char*)&newrecord, sizeof(newrecord));
					cout<<"New Data-> ";
					newrecord.showData();
				}
			}
			f1.close();
			f2.close();
			if((remove(mainstudentfile))==0)
			{
				rename(tempstudentfile,mainstudentfile);
				cout<<endl<<"Modification of record is successful"<<endl;
			}
			else
			{
				cout<<"Error in modification of record"<<endl;
			}
		}
		else
			cout<<endl<<"Student's ID not found";
	}

	bool SearchIDMarks(char temp[])
	{
		fstream f;
		Marks search;
		f.open(mainmarksfile, ios::in|ios::binary);
		while((f.read((char*)&search, sizeof(search))))
		{
			if(compare(search.getid(), temp)==true)
			{
				f.close();
				return true;
			}
		}
		f.close();
		return false;
	}
	void InsertMarks()
	{
		fstream f;
		Marks newinsert;
		newinsert.getData();
		if(SearchIDMarks(newinsert.getid())==false)
		{
			f.open(mainmarksfile, ios::app|ios::binary);
			f.write((char*) &newinsert, sizeof(newinsert));
			f.close();
			cout<<"Marks Record added successfully"<<endl;
		}
		else
			cout<<"Marks Record with same Student ID exists"<<endl;
	}
	void UpdateMarks()
	{
		char temp[IDlength];
		Marks deleterecord,newrecord;
		cout<<"Enter Student's ID for Marks updation: ";
		cin>>temp;
		newrecord.setid(temp);
		if(SearchIDStudents(newrecord.getid())==true)
		{
			fstream f1,f2;
			f1.open(mainmarksfile, ios::in|ios::binary);
			f2.open(tempmarksfile, ios::app|ios::binary);
			while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
			{
				if(compare(deleterecord.getid(), temp)==false)
				{
					f2.write((char*)&deleterecord, sizeof(deleterecord));
				}
				else
				{
					int flag1, flag2;
					do
					{
						cout<<endl<<"Enter 1 to upadte marks for DBMS, 2 for DS, 3 for C, 0 for no change:";
						cin>>flag1;
						cout<<"Enter marks for updation (less than or equal to 100) in";
						switch(flag1)
						{
							case 1:
								cout<<" DBMS: ";
								cin>>flag2;
								if(flag2>100)
									break;
								newrecord.setData(deleterecord);
								newrecord.setmdbms(flag2);
								break;

							case 2:
								cout<<" DS: ";
								cin>>flag2;
								if(flag2>100)
									break;
								newrecord.setData(deleterecord);
								newrecord.setmds(flag2);
								break;

							case 3:
								cout<<" C: ";
								cin>>flag2;
								if(flag2>100)
									break;
								newrecord.setData(deleterecord);
								newrecord.setmc(flag2);
								break;

							case 0:
								newrecord.setData(deleterecord);
								break;

							default:
								cout<<"Choose between 1-3 only"<<endl;
						}
					}while((flag1>3)||(flag2>100));

					newrecord.calculatetotal();
					newrecord.calculatepercentage();
					cout<<"New Data-> ";
					newrecord.showData();
					f2.write((char*)&newrecord, sizeof(newrecord));
				}
			}
			f1.close();
			f2.close();
			if((remove(mainmarksfile))==0)
			{
				rename(tempmarksfile,mainmarksfile);
				cout<<endl<<"Modification of record is successful"<<endl;
			}
			else
			{
				cout<<"Error in modification of record"<<endl;
			}
		}
		else
			cout<<endl<<"Student's ID not found";
	}
	void DisplayMarks()
	{
		fstream f;
		Marks display;
		f.open(mainmarksfile, ios::in|ios::binary);
		while((f.read((char*)&display, sizeof(display))))
		{
			display.showData();
		}
	}
	void DeleteMarks(Marks deletemarks)
	{
		Marks deleterecord;
		fstream f1,f2;
		f1.open(mainmarksfile, ios::in|ios::binary);
		f2.open(tempmarksfile, ios::app|ios::binary);
		while((f1.read((char*)&deleterecord, sizeof(deleterecord))))
		{
			if(compare(deleterecord.getid(), deletemarks.getid())==false)
			{
				f2.write((char*)&deleterecord, sizeof(deleterecord));
			}
		}
		f1.close();
		f2.close();
		remove(mainmarksfile);
		rename(tempmarksfile,mainmarksfile);
	}
	void DisplayAbovePercent()
	{
		fstream f;
		Marks display;
		double minpercent;
		cout<<"Enter the minimum percent criteria";
		cin>>minpercent;
		f.open(mainmarksfile, ios::in|ios::binary);
		while((f.read((char*)&display, sizeof(display))))
		{
			if(display.getpercentage()>=minpercent)
				display.showData();
		}
	}
	void DisplayAbovePercentandBranch()
	{
		fstream f1,f2,f3,f4;
		Marks displaypercent;
		Student displaybranch;
		double minpercent;
		cout<<"Enter the minimum percent criteria";
		cin>>minpercent;
		char branch[Blength];
		cout<<"Enter branch";
		cin>>branch;
		f1.open(mainmarksfile, ios::in|ios::binary);
		f2.open(tempmarksfile, ios::app|ios::binary);
		f3.open(mainstudentfile, ios::in|ios::binary);
		f4.open(mainstudentfile, ios::app|ios::binary);
		while((f1.read((char*)&displaypercent, sizeof(displaypercent))))
		{
			if(displaypercent.getpercentage()>=minpercent)
				f2.write((char*)&displaypercent, sizeof(displaypercent));
		}
		while((f3.read((char*)&displaybranch, sizeof(displaybranch))))
		{
			if(compare(displaybranch.getbranch(),branch)==true)
				f4.write((char*)&displaybranch, sizeof(displaybranch));
		}
		f1.close();
		f2.close();
		f3.close();
		f4.close();
		f1.open(tempmarksfile, ios::in|ios::binary);
		f2.open(tempstudentfile, ios::in|ios::binary);
		while((f1.read((char*)&displaypercent, sizeof(displaypercent))))
		{
			while((f2.read((char*)&displaybranch, sizeof(displaybranch))))
			{
				if(compare(displaybranch.getid(),displaypercent.getid())==true)
				{
					cout<<"Student ID: "<<displaybranch.getid()<<", Name: "<<displaybranch.getname()<<", Branch: "<<displaybranch.getbranch()<<", Marks in DBMS: "<<displaypercent.getmdbms()<<", DS: "<<displaypercent.getmds()<<", C: "<<displaypercent.getmc()<<", Total: "<<displaypercent.gettotal()<<", Percentage: "<<displaypercent.getpercentage()<<"%";
				}
			}
		}
		f1.close();
		f2.close();
	}
};

int main()
{
	AdminStudent arpit;
	bool flag=true;
		cout<<"Student's Administrator Console"<<endl;
		cout<<"1: To add a student in database."<<endl;
		cout<<"2. To modify the name of a student."<<endl;
		cout<<"3. To modify the branch of a student."<<endl;
		cout<<"4. To delete the student's data from database"<<endl;
		cout<<"5. Search the student using BRANCH."<<endl;
		cout<<"6. Search the student using NAME."<<endl;
		cout<<"7. Insert marks of a registered student."<<endl;
		cout<<"8. Update marks of a student."<<endl;
		cout<<"9. Display marks of all the students."<<endl;
		cout<<"10. Search for students with percentage above a particular threshold."<<endl;
		cout<<"11. Search for students of a particular branch with percentage above a threshold."<<endl;
		cout<<"0. To exit this Program"<<endl;
	while(flag)
	{
		cout<<endl	<<"Enter value:";
		int in;
		cin>>in;
		switch(in)
		{
			case 1:
				arpit.AddRecord();
				break;

			case 2:
				arpit.ModifyName();
				break;

			case 3:
				arpit.ModifyBranch();
				break;

			case 4:
				arpit.Delete();
				break;

			case 5:
				arpit.SearchBranch();
				break;

			case 6:
				arpit.SearchName();
				break;

			case 7:
				arpit.InsertMarks();
				break;

			case 8:
				arpit.UpdateMarks();
				break;

			case 9:
				arpit.DisplayMarks();
				break;

			case 10:
				arpit.DisplayAbovePercent();
				break;

			case 11:
				arpit.DisplayAbovePercentandBranch();
				break;

			case 0:
			flag=false;
		}
	}
	return 0;
}