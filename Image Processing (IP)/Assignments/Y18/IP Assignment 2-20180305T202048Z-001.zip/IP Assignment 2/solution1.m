% Reading the image
image = imread('image.jpg');
% Converting to gray scale
grayImage = rgb2gray(image);
% Reducing the gray levels to 64
image64 = uint8(floor(double(grayImage)/4)*4);
imshow(image64);
% Reducing the gray levels to 16
image16 = uint8(floor(double(grayImage)/8)*8);
imshow(image16);
% Reducing the gray levels to 8
image8 = uint8(floor(double(grayImage)/16)*16);
imshow(image8);
% Reducing the gray levels to 4
image4 = uint8(floor(double(grayImage)/32)*32);
imshow(image4);