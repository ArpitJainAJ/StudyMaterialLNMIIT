% Reading the image
image = imread('image.jpg');
% Converting to gray scale
grayImage = rgb2gray(image);
% Changing the resolution of the image to half
newImage = Resolution(grayImage);
imshow(newImage);