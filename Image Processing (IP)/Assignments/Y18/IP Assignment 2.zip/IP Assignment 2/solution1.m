% Reducing the gray level to 64
image64 = uint8(floor(double(grayDemo)/4));
%imshow(image64);
% Reducing the gray level to 16
image16 = uint8(floor(double(grayDemo)/8));
%imshow(image16);
% Reducing the gray level to 8
image8 = uint8(floor(double(grayDemo)/16));
%imshow(image8);
% Reducing the gray level to 4
image4 = uint8(floor(double(grayDemo)/32));
%imshow(image4);